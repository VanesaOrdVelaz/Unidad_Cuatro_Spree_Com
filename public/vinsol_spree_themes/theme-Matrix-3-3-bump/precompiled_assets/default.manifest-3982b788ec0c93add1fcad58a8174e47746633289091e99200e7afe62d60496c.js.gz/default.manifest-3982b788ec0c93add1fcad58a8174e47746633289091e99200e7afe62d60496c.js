// all javascript files related to themes should be require in this manifest.
$( document ).ready(function() {
  $( ".number_field_tag" ).spinner({
    min: 1
  });
});
